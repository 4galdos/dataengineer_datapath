
CREATE TABLE `category` (
  `categoryid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`categoryid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `consumer` (
  `customerid` int NOT NULL AUTO_INCREMENT,
  `identitynumber` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `address` varchar(200) DEFAULT NULL,
  `districtid` int DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  PRIMARY KEY (`customerid`),
  KEY `districtid` (`districtid`),
  CONSTRAINT `consumer_ibfk_1` FOREIGN KEY (`districtid`) REFERENCES `district` (`districtid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `district` (
  `districtid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`districtid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `invoice` (
  `invoiceid` int NOT NULL AUTO_INCREMENT,
  `invoice_date` datetime NOT NULL,
  `order_number` varchar(20) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `customerid` int DEFAULT NULL,
  PRIMARY KEY (`invoiceid`),
  KEY `customerid` (`customerid`),
  CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`customerid`) REFERENCES `consumer` (`customerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `invoice_detail` (
  `itemid` int NOT NULL AUTO_INCREMENT,
  `invoiceid` int DEFAULT NULL,
  `productid` int DEFAULT NULL,
  `quantity` int NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `igv` decimal(10,2) NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `invoiceid` (`invoiceid`),
  KEY `productid` (`productid`),
  CONSTRAINT `invoice_detail_ibfk_1` FOREIGN KEY (`invoiceid`) REFERENCES `invoice` (`invoiceid`),
  CONSTRAINT `invoice_detail_ibfk_2` FOREIGN KEY (`productid`) REFERENCES `products` (`productid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `products` (
  `productid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `categoryid` int DEFAULT NULL,
  `stock` int DEFAULT NULL,
  PRIMARY KEY (`productid`),
  KEY `categoryid` (`categoryid`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`categoryid`) REFERENCES `category` (`categoryid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
